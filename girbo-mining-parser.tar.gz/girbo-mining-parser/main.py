#!/usr/bin/env python3
# main.py — точка входа

import argparse
import logging
from src.parser import run

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)


def main():
    parser = argparse.ArgumentParser(
        description="ГИРБО Mining Parser — поиск майнинговых компаний по бухотчётности"
    )

    parser.add_argument(
        "--mode",
        choices=["api", "file"],
        default="api",
        help="Источник ИНН: api (ЕГРЮЛ) или file (из файла)",
    )
    parser.add_argument(
        "--input",
        type=str,
        default=None,
        help="Путь к файлу с ИНН (TXT или CSV). Обязателен при --mode file",
    )
    parser.add_argument(
        "--min-ee",
        type=float,
        default=5_000_000,
        dest="min_electricity",
        help="Минимальные расходы на ЭЭ в рублях (по умолчанию: 5 000 000)",
    )
    parser.add_argument(
        "--year",
        type=int,
        default=2023,
        help="Год отчётности (по умолчанию: 2023)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Путь к выходному CSV файлу (по умолчанию: output/mining_leads_ДАТА.csv)",
    )

    args = parser.parse_args()

    if args.mode == "file" and not args.input:
        parser.error("--mode file требует указания --input путь/к/файлу.txt")

    run(
        mode=args.mode,
        input_file=args.input,
        min_electricity=args.min_electricity,
        year=args.year,
        output_file=args.output,
    )


if __name__ == "__main__":
    main()
