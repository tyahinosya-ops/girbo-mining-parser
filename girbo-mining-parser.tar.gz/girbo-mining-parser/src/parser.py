# src/parser.py — основной парсер

import time
import logging
import requests
from pathlib import Path
import pandas as pd
from datetime import date

from config import (
    OKVEDS,
    TARGET_REGIONS,
    REQUEST_DELAY,
    REQUEST_TIMEOUT,
    MIN_REVENUE,
    MIN_SCORE,
    OUTPUT_DIR,
    DEFAULT_OUTPUT_FILE,
)
from src.extractor import get_report_from_girbo, extract_electricity_expenses, extract_key_financials
from src.scoring import calculate_mining_score, get_priority_label

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False

log = logging.getLogger(__name__)

EGRUL_SEARCH_URL = "https://egrul.nalog.ru/search-results"


# ─────────────────────────────────────────────
# Получение ИНН из ЕГРЮЛ
# ─────────────────────────────────────────────

def get_inns_from_api(okveds: list = OKVEDS, regions: list = TARGET_REGIONS) -> list[str]:
    """Собирает ИНН компаний из ЕГРЮЛ по ОКВЭД и регионам."""
    inns = set()

    total = len(okveds) * len(regions)
    log.info(f"Запросов к ЕГРЮЛ: {total} (ОКВЭД × регионы)")

    for okvd in okveds:
        for region in regions:
            try:
                resp = requests.get(
                    EGRUL_SEARCH_URL,
                    params={"query": "", "region": region, "okvd": okvd, "rows": 100},
                    timeout=REQUEST_TIMEOUT,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    for company in data.get("rows", []):
                        inn = company.get("i", "")
                        if inn:
                            inns.add(inn)
                    log.debug(f"ОКВЭД {okvd} / Регион {region}: +{len(data.get('rows', []))}")
                time.sleep(REQUEST_DELAY)
            except Exception as e:
                log.warning(f"Ошибка ЕГРЮЛ ({okvd}/{region}): {e}")

    result = list(inns)
    log.info(f"Собрано уникальных ИНН: {len(result)}")
    return result


def load_inns_from_file(filepath: str) -> list[str]:
    """Загружает ИНН из TXT или CSV файла."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Файл не найден: {filepath}")

    if filepath.endswith(".csv") or filepath.endswith(".xlsx"):
        df = pd.read_csv(filepath) if filepath.endswith(".csv") else pd.read_excel(filepath)
        # Автоопределение колонки с ИНН
        inn_col = next(
            (c for c in df.columns if "инн" in c.lower() or "inn" in c.lower()),
            df.columns[0]
        )
        inns = df[inn_col].astype(str).str.strip().tolist()
    else:
        with open(filepath, encoding="utf-8") as f:
            inns = [line.strip() for line in f if line.strip()]

    # Базовая валидация ИНН (10 или 12 цифр)
    valid = [i for i in inns if i.isdigit() and len(i) in (10, 12)]
    log.info(f"Загружено ИНН из файла: {len(valid)} (отфильтровано невалидных: {len(inns)-len(valid)})")
    return valid


# ─────────────────────────────────────────────
# Основной пайплайн
# ─────────────────────────────────────────────

def run(
    mode: str = "api",
    input_file: str = None,
    min_electricity: float = 5_000_000,
    year: int = 2023,
    output_file: str = None,
) -> pd.DataFrame:

    # 1. Получить ИНН
    if mode == "file" and input_file:
        inns = load_inns_from_file(input_file)
    else:
        inns = get_inns_from_api()

    if not inns:
        log.error("Список ИНН пуст — проверьте настройки или файл")
        return pd.DataFrame()

    # 2. Обработать каждый ИНН
    results = []
    iterator = tqdm(inns, desc="Анализ отчётности") if HAS_TQDM else inns

    for inn in iterator:
        time.sleep(REQUEST_DELAY)

        report_data = get_report_from_girbo(inn, year=year)
        if not report_data:
            continue

        electricity = extract_electricity_expenses(report_data)
        financials = extract_key_financials(report_data)
        score, triggers = calculate_mining_score(financials, electricity)

        # Фильтрация
        if financials["revenue"] < MIN_REVENUE:
            continue
        if electricity < min_electricity and score < MIN_SCORE:
            continue

        results.append({
            "ИНН": inn,
            "Компания": report_data.get("org_name", ""),
            "Полное_наименование": report_data.get("full_name", ""),
            "Регион": report_data.get("region", ""),
            "ОКВЭД": report_data.get("okvd_main", ""),
            "Расходы_ЭЭ_руб": int(electricity),
            "Выручка_руб": int(financials["revenue"]),
            "Себестоимость_руб": int(financials["cost_of_sales"]),
            "ОС_руб": int(financials["fixed_assets"]),
            "Баланс_руб": int(financials["balance_total"]),
            "Чистая_прибыль_руб": int(financials["net_profit"]),
            "Сотрудников": financials["employees"],
            "Скоринг_майнинг": score,
            "Приоритет": get_priority_label(score),
            "Триггеры": " | ".join(triggers),
        })

    if not results:
        log.warning("Не найдено компаний по заданным критериям")
        return pd.DataFrame()

    # 3. Сохранить
    df = pd.DataFrame(results)
    df = df.sort_values("Скоринг_майнинг", ascending=False).reset_index(drop=True)

    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    today = date.today().strftime("%Y-%m-%d")
    out = output_file or f"{OUTPUT_DIR}/{DEFAULT_OUTPUT_FILE}_{today}.csv"
    df.to_csv(out, index=False, encoding="utf-8-sig")

    # 4. Итоговая статистика
    hot = len(df[df["Приоритет"].str.contains("Горячий")])
    warm = len(df[df["Приоритет"].str.contains("Тёплый")])
    cold = len(df[df["Приоритет"].str.contains("Холодный")])

    print("\n" + "="*55)
    print(f"  ✅ Готово! Найдено компаний: {len(df)}")
    print(f"  🔴 Горячих лидов:  {hot}")
    print(f"  🟡 Тёплых лидов:   {warm}")
    print(f"  🟢 Холодных лидов: {cold}")
    print(f"  📁 Файл: {out}")
    print("="*55 + "\n")

    return df
